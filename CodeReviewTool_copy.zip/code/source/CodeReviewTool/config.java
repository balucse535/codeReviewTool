package CodeReviewTool;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2014-08-06 12:08:11 IST
// -----( ON-HOST: FCSHYDDW0214.fcs-inc.local

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
import com.wm.app.b2b.server.*;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class config

{
	// ---( internal utility methods )---

	final static config _instance = new config();

	static config _newInstance() { return new config(); }

	static config _cast(Object o) { return (config)o; }

	// ---( server methods )---




	public static final void getConfig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getConfig)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] record:0:required config
		IDataCursor idcPipeline = pipeline.getCursor();
		//System.out.println("properties = " + properties);
		idcPipeline.insertAfter("properties", properties);
		// --- <<IS-END>> ---

                
	}



	public static final void getParam (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getParam)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required paramName
		// [o] field:0:required paramValue
		
		IDataCursor idcPipeline = pipeline.getCursor();
		String strParamName = null;
		if (idcPipeline.first("paramName"))
		{
		  strParamName = (String) idcPipeline.getValue();
		}
		else
		{
		  throw new ServiceException("Parameter name cannot be null!");
		}
		
		String strParamValue = (String) properties.get(strParamName);
		idcPipeline.insertAfter("paramValue", strParamValue);
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Properties properties = new Properties();
	// --- <<IS-END-SHARED>> ---
}

