package CodeReviewTool.util;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-02-10 17:24:12 IST
// -----( ON-HOST: HSCSRV164.allegisgroup.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.sun.org.apache.xerces.internal.impl.xs.util.StringListImpl;
import com.wm.app.b2b.server.ServerAPI;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;
import com.wm.app.b2b.client.*;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class Java

{
	// ---( internal utility methods )---

	final static Java _instance = new Java();

	static Java _newInstance() { return new Java(); }

	static Java _cast(Object o) { return (Java)o; }

	// ---( server methods )---




	public static final void addToList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addToList)>> ---
		// @sigtype java 3.5
		// [i] object:0:required list
		// [i] record:0:required Document
		// [o] object:0:required list
		com.wm.util.List l = (com.wm.util.List) ValuesEmulator.get(pipeline, "list");
		Object o = ValuesEmulator.get(pipeline, "Document");
		l.addElement(o);
		// --- <<IS-END>> ---

                
	}



	public static final void containsString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(containsString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required String1
		// [i] field:0:required String2
		// [o] field:0:required res
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	String1 = IDataUtil.getString( pipelineCursor, "String1" );
			String	String2 = IDataUtil.getString( pipelineCursor, "String2" );
			String strResult="false";
			if(String1.contains(String2))
				strResult="true";
				
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "res", strResult );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void createList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createList)>> ---
		// @sigtype java 3.5
		// [i] field:0:optional initialListSize
		// [o] object:0:required list
		String initialListSize = (String) ValuesEmulator.get(pipeline, "initialListSize");
		com.wm.util.List l = null;
		
		if (initialListSize == null)
		{
		  l = new com.wm.util.List(100); // default list size
		}
		else
		{
		  l = new com.wm.util.List(Integer.parseInt(initialListSize));
		}
		
		ValuesEmulator.put(pipeline, "list", l);
			
		// --- <<IS-END>> ---

                
	}



	public static final void getBPMSignatureVerified (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getBPMSignatureVerified)>> ---
		// @sigtype java 3.5
		// [i] field:1:required processInputs
		// [i] field:1:required serviceInputs
		// [o] field:0:required isMatch
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	processInputs = IDataUtil.getStringArray( pipelineCursor, "processInputs" );
			String[]	serviceInputs = IDataUtil.getStringArray( pipelineCursor, "serviceInputs" );
		pipelineCursor.destroy();
		int processInputLength = 0;
		int serviceInputLength = 0;
		String flag = "true";
		String match = "false";
		if(processInputs != null)
			processInputLength = processInputs.length;
		if(serviceInputs != null)
			serviceInputLength = serviceInputs.length;
		if(processInputLength == serviceInputLength)
		{
			for (int i = 0 ; i < processInputLength ; i++ )
			{
				if(flag == "false")
					break ;
				for (int j = 0 ; j < processInputLength ; j++)
				{
					if(processInputs[i].equals(serviceInputs[j]))
					{
						match = "true";
						break;
					}
					if(j == processInputLength - 1)
					{
						match = "false";
						flag = "false";
					}
					
				}
			}
			
		}
			
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isMatch", match );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getFilesAndDirs (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFilesAndDirs)>> ---
		// @sigtype java 3.5
		// [i] field:0:required PackageName
		// [o] field:1:required RootFolders
		// [o] field:1:required SubFolders
		// [o] field:1:required Services
		// [o] field:1:required NodePathList
		// [o] field:1:required FlowPathList
		// [o] field:1:required JavaPathList
		// [o] field:1:required FlowJavaNodePathList
		// [o] field:1:required FlowNodePathList
		// [o] field:1:required ServiceDirPathList
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	PackageName = IDataUtil.getString( pipelineCursor, "PackageName" );
		String NSDirPath="."+File.separator+"packages"+File.separator+PackageName+File.separator+"ns";
		try{
			File fileNSDirPath=new File(NSDirPath);
			getFileListing(fileNSDirPath);
			if(SubFolders.size()>0)
			SubFolders.remove(0);
			IDataUtil.put(pipelineCursor, "RootFolders",(String[])RootFolders.toArray(new String[RootFolders.size()]));
			IDataUtil.put(pipelineCursor, "SubFolders",(String[])SubFolders.toArray(new String[SubFolders.size()]));
			IDataUtil.put(pipelineCursor, "Services",(String[])Services.toArray(new String[Services.size()]));
			IDataUtil.put(pipelineCursor, "NodePathList",(String[])NodePathList.toArray(new String[NodePathList.size()]));
			IDataUtil.put(pipelineCursor, "FlowPathList",(String[])FlowPathList.toArray(new String[FlowPathList.size()]));
			IDataUtil.put(pipelineCursor, "JavaPathList",(String[])JavaPathList.toArray(new String[JavaPathList.size()]));
			IDataUtil.put(pipelineCursor, "FlowJavaNodePathList",(String[])FlowJavaNodePathList.toArray(new String[FlowJavaNodePathList.size()]));
			IDataUtil.put(pipelineCursor, "FlowNodePathList",(String[])FlowNodePathList.toArray(new String[FlowNodePathList.size()]));
			IDataUtil.put(pipelineCursor, "ServiceDirPathList",(String[])ServiceDirPathList.toArray(new String[ServiceDirPathList.size()]));
		}catch(FileNotFoundException fnfe){
			throw new ServiceException("File Not Found");
		}catch(Exception e){
			throw new ServiceException(e);
		}finally{
			RootFolders.clear();
			SubFolders.clear();
			Services.clear();
			NodePathList.clear();
			FlowPathList.clear();
			JavaPathList.clear();
			FlowJavaNodePathList.clear();
			FlowNodePathList.clear();
			ServiceDirPathList.clear();
		}
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFilesFromPkgAndPath (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFilesFromPkgAndPath)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:required ConfigCanonicalPath
		// [o] field:1:required RootFolders
		// [o] field:1:required SubFolders
		// [o] field:1:required Services
		// [o] field:1:required NodePathList
		// [o] field:1:required FlowPathList
		// [o] field:1:required JavaPathList
		// [o] field:1:required FlowJavaNodePathList
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
		String NSDirPath=null;
		String ConfigCanonicalPath=null;
		ConfigCanonicalPath=IDataUtil.getString(pipelineCursor,"ConfigCanonicalPath");
		if(!(ConfigCanonicalPath.equalsIgnoreCase("") || ConfigCanonicalPath.equalsIgnoreCase(null))){
			NSDirPath="."+File.separator+"packages"+File.separator+packageName+File.separator+"ns"+File.separator+packageName+File.separator+ConfigCanonicalPath;
			}
		try{
			File fileNSDirPath=new File(NSDirPath);
			getFileListing(fileNSDirPath);
			SubFolders.remove(0); 
			IDataUtil.put(pipelineCursor, "RootFolders",(String[])RootFolders.toArray(new String[RootFolders.size()]));
			IDataUtil.put(pipelineCursor, "SubFolders",(String[])SubFolders.toArray(new String[SubFolders.size()]));
			IDataUtil.put(pipelineCursor, "Services",(String[])Services.toArray(new String[Services.size()]));
			IDataUtil.put(pipelineCursor, "FlowPathList",(String[])FlowPathList.toArray(new String[FlowPathList.size()]));
			IDataUtil.put(pipelineCursor, "JavaPathList",(String[])JavaPathList.toArray(new String[JavaPathList.size()]));
			IDataUtil.put(pipelineCursor, "NodePathList",(String[])NodePathList.toArray(new String[NodePathList.size()]));
			IDataUtil.put(pipelineCursor, "FlowJavaNodePathList",(String[])FlowJavaNodePathList.toArray(new String[FlowJavaNodePathList.size()]));
		
		}catch(FileNotFoundException fnfe){
			throw new ServiceException("File Not Found");
		}catch(Exception e){
			throw new ServiceException(e);
		}finally{
			RootFolders.clear();
			SubFolders.clear();
			Services.clear();
			NodePathList.clear();
			FlowPathList.clear();
			JavaPathList.clear();
			FlowJavaNodePathList.clear();
		}
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getInputOutputServiceSignature (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getInputOutputServiceSignature)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required ServiceName
		// [o] field:0:required strInputSigStatus
		// [o] field:0:required strOutputSigStatus
		// [o] field:1:required sServiceInputName
		// [o] field:1:required sServiceOutputName
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	ServiceName = IDataUtil.getString( pipelineCursor, "ServiceName" );	
		NSName objNsName = NSName.create(ServiceName);
		NSService objServiceName = com.wm.app.b2b.server.ns.Namespace.getService(objNsName);
		NSSignature objSignature  = objServiceName.getSignature();
		NSRecord  objRecordInput =null;
		NSRecord  objRecordOutput =null;
		NSField[] objFieldOutput =null;
		NSField[] objFieldInput =null;
		
		if(objSignature!=null)
		{
		objRecordInput = objSignature.getInput();
		objRecordOutput = objSignature.getOutput();
		}
		String strInputSignature = "true";
		String strOutputSignature = "true";
		
		if(objRecordInput!=null)
		{
		 objFieldInput = objRecordInput.getFields();
		}
		if(objRecordOutput!=null)
			objFieldOutput = objRecordOutput.getFields();
		if(objFieldInput==null || objFieldInput.length==0)
			strInputSignature = "false";
		if(objFieldOutput==null ||objFieldOutput.length==0)
			strOutputSignature = "false";
		
		String[] strInputFieldName= new String[objFieldInput.length];
		if(strInputSignature.equals("true"))
		  {
			for(int i=0;i<objFieldInput.length;i++)
			  strInputFieldName[i] = objFieldInput[i].getName();
			  
				  
		  }
		String[] strOutputFieldName= new String[objFieldOutput.length];
		if(strOutputSignature.equals("true"))
		  {
			for(int i=0;i<objFieldOutput.length;i++)
				strOutputFieldName[i] = objFieldOutput[i].getName();
			  
				  
		  }
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "strInputSigStatus", "strInputSigStatus" );
		IDataUtil.put( pipelineCursor_1, "strOutputSigStatus", "strOutputSigStatus" );
		IDataUtil.put( pipelineCursor_1, "sServiceInputName", strInputFieldName );
		IDataUtil.put( pipelineCursor_1, "sServiceOutputName", strOutputFieldName );
		pipelineCursor_1.destroy();
		
		
		
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getInputServiceSignature (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getInputServiceSignature)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required ServiceName
		// [o] field:0:required strInputSigStatus
		// [o] field:0:required strOutputSigStatus
		// [o] field:1:required sServiceInputName
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	ServiceName = IDataUtil.getString( pipelineCursor, "ServiceName" );	
		NSName objNsName = NSName.create(ServiceName);
		NSService objServiceName = com.wm.app.b2b.server.ns.Namespace.getService(objNsName);
		NSSignature objSignature  = objServiceName.getSignature();
		NSRecord  objRecordInput =null;
		NSRecord  objRecordOutput =null;
		NSField[] objFieldOutput =null;
		NSField[] objFieldInput =null;
		
		if(objSignature!=null)
		{
		objRecordInput = objSignature.getInput();
		objRecordOutput = objSignature.getOutput();
		}
		String strInputSignature = "true";
		String strOutputSignature = "true";
		
		if(objRecordInput!=null)
		{
		 objFieldInput = objRecordInput.getFields();
		}
		if(objRecordOutput!=null)
			objFieldOutput = objRecordOutput.getFields();
		if(objFieldInput==null || objFieldInput.length==0)
			strInputSignature = "false";
		if(objFieldOutput==null ||objFieldOutput.length==0)
			strOutputSignature = "false";
		
		String[] strInputFieldName= new String[objFieldInput.length];
		if(strInputSignature.equals("true"))
		  {
			for(int i=0;i<objFieldInput.length;i++)
			  strInputFieldName[i] = objFieldInput[i].getName();
			  
				  
		  }
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "strInputSigStatus", "strInputSigStatus" );
		IDataUtil.put( pipelineCursor_1, "strOutputSigStatus", "strOutputSigStatus" );
		IDataUtil.put( pipelineCursor_1, "sServiceInputName", strInputFieldName );
		pipelineCursor_1.destroy();
		
		
		
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getJavaServieFolder (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getJavaServieFolder)>> ---
		// @sigtype java 3.5
		// [i] field:0:required javaServiceName
		// [o] field:0:required javaServiceFolder
			
		String javaServiceFolder = null;
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	javaServiceName = IDataUtil.getString( pipelineCursor, "javaServiceName" );
		pipelineCursor.destroy();
		if(javaServiceName != null){
		javaServiceName = javaServiceName.substring(0, javaServiceName.indexOf(":"));
		javaServiceName = javaServiceName.substring(0, javaServiceName.lastIndexOf("."));
		javaServiceName = javaServiceName.substring(javaServiceName.indexOf(".")+1);
		javaServiceFolder = javaServiceName;
		}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "javaServiceFolder", javaServiceFolder );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getListSize (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getListSize)>> ---
		// @sigtype java 3.5
		// [i] object:0:required list
		// [o] field:0:required size
		com.wm.util.List l = (com.wm.util.List) ValuesEmulator.get(pipeline, "list");
		int size = l.size();
		ValuesEmulator.put(pipeline, "size", Integer.toString(size));
		// --- <<IS-END>> ---

                
	}



	public static final void getNoOfNodesInLevel (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNoOfNodesInLevel)>> ---
		// @sigtype java 3.5
		// [i] field:0:required NoOfLevels
		// [i] field:0:required FlowPathList
		// [o] field:0:required NoOfSteps
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	NoOfLevels = IDataUtil.getString( pipelineCursor, "NoOfLevels" );
			String	FlowPathList = IDataUtil.getString( pipelineCursor, "FlowPathList" );
		pipelineCursor.destroy();
		int NoOfLevel=Integer.parseInt(NoOfLevels);
		List childlist = new ArrayList();
		try {
				SAXBuilder builder = new SAXBuilder();
				File xmlFile = new File(FlowPathList);
				Document doc = (Document) builder.build(xmlFile);
				Element rootNode = doc.getRootElement();
				count=0;
				depth=0;
				Namespace nsroot=rootNode.getNamespace();
		//				System.out.println("xmlns>>"+nsroot);
		//				System.out.println("rootnode name:+++"+rootNode.getName());
				rootNode.removeChild("COMMENT");
				Iterator nodeItr=rootNode.getChildren().iterator();
				while(nodeItr.hasNext()){
					count++;
					depth=1;
					Element node=(Element)nodeItr.next();
					node.removeChild("COMMENT");
					if(node.getChildren().size() > 0){
						if(depth <= NoOfLevel){
							recurseThroughDoc(node,NoOfLevel);
						}
					}
				}
			         
		  } catch (IOException io) {
				io.printStackTrace();
		  }  catch (JDOMException e) {
			  	e.printStackTrace();
		  }   
			
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "NoOfSteps", count+"");
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getNodeType (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNodeType)>> ---
		// @sigtype java 3.5
		// [i] object:0:required type
		// [o] field:0:required type_name
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		Object	type = IDataUtil.get( pipelineCursor, "type" );
		String strClassName= type.getClass().getName(); 
		com.wm.util.JournalLogger.log(3,90,3,"LOG " + "############################## strClassName "+strClassName);
		String strValue = "non-record";
		if(strClassName.equals("com.wm.lang.ns.NSType"))
		{
			com.wm.lang.ns.NSType rec=(com.wm.lang.ns.NSType)type;
			IData objIData = rec.getAsData();
			IDataCursor objCursor = objIData.getCursor();
			objCursor.first("type_name");
			strValue = (String)objCursor.getValue();
			com.wm.util.JournalLogger.log(3,90,3,"LOG " + "############################## strValue "+strValue);
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "type_name", strValue );
			pipelineCursor_1.destroy();
		}
		
		else
		{
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "type_name", strValue );
			pipelineCursor_1.destroy();
		}
		pipelineCursor.destroy();
		
		// pipeline
			
		// --- <<IS-END>> ---

                
	}



	public static final void getNonWmPackages (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNonWmPackages)>> ---
		// @sigtype java 3.5
		// [o] field:1:required listOfNonWmPackages
		List<String> nonWmPackageList = new ArrayList<String>();
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String[] packages=ServerAPI.getPackages();
		for(String pkg:packages){
			if(!pkg.startsWith("Wm")&&!pkg.startsWith("WM")&&!pkg.startsWith("wM")&&!pkg.startsWith("wm")&& !pkg.equals("Default")&&!pkg.contains("Sample")&&!pkg.contains("CodeReviewTool")){
				nonWmPackageList.add(pkg);
			}
		}
		String[] nonWmPackages=(String[])nonWmPackageList.toArray(new String[nonWmPackageList.size()]);
		IDataUtil.put( pipelineCursor, "listOfNonWmPackages",nonWmPackages);
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPathForManifest (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPathForManifest)>> ---
		// @sigtype java 3.5
		// [i] field:0:required PackageName
		// [o] field:0:required ManifestAbsolutePath
		String ManifestAbsolutePath = null;
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	PackageName = IDataUtil.getString( pipelineCursor, "PackageName" );
			String tempPath = "."+File.separator+"packages"+File.separator+PackageName;
			File fileDirPath = new File(tempPath);
			File[] fileList = fileDirPath.listFiles();
			for(File file : fileList){
				
				if(file.getName().equalsIgnoreCase("manifest.v3"))
				{
					ManifestAbsolutePath = file.getAbsolutePath();
				}
			}
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "ManifestAbsolutePath", ManifestAbsolutePath );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceAuditing (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceAuditing)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required ServiceName
		// [o] field:0:required sStatus
		//pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	ServiceName = IDataUtil.getString( pipelineCursor, "ServiceName" );
		pipelineCursor.destroy();
		NSName objNsName = NSName.create(ServiceName);
		NSService objServiceName = com.wm.app.b2b.server.ns.Namespace.getService(objNsName);	
		int intAuditEnable = objServiceName.getAuditOption();
		
		String strAuditEnable="true"; 
		
		if(intAuditEnable==0)
		{
		
		// pipeline
		
		strAuditEnable = "false";
		
		
		
		}
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "sStatus", strAuditEnable);
		pipelineCursor_1.destroy();
		
		
		
		
		
		
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceDebugOption (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceDebugOption)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required ServiceName
		// [o] field:0:required sStatus
		//pipeline
				IDataCursor pipelineCursor = pipeline.getCursor();
				String	ServiceName = IDataUtil.getString( pipelineCursor, "ServiceName" );
				pipelineCursor.destroy();
				NSName objNsName = NSName.create(ServiceName);
				NSService objServiceName = com.wm.app.b2b.server.ns.Namespace.getService(objNsName);	
				boolean booRestorePipeline = objServiceName.isRestorePipeline();
				
				String strRestoreExists="false";
				
				if(booRestorePipeline)
				{
				
				// pipeline
				
					strRestoreExists = "true";
				
				
				
				}
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				IDataUtil.put( pipelineCursor_1, "sStatus", strRestoreExists);
				pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceNameFromPath (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceNameFromPath)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inputPath
		// [o] field:0:required serviceName
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	inputPath = IDataUtil.getString( pipelineCursor, "inputPath" );
		/*****************************************************************************
		Example of a Flow Path is C:\SoftwareAG\IntegrationServer\.\packages\TestPackageForInput\ns\TestPackageForInput\FlowServiceWithoutTimeOut\flow.xml
		
		1. Split Input string at \ns\. The string after ns denotes the name of the service.
		2. Remove flow.xml and node.ndf from the String.
		3. Format the Service Name to the format posted by Developer.
		
		******************************************************************************/
		
		// Split Input String at \ns\
		
		String fileSeparator = System.getProperty("file.separator", "No property found");
		if (fileSeparator.equals("\\")) {
			fileSeparator = "\\\\";		//Windows
		}
		
		String splitPath[] = inputPath.split(fileSeparator+"ns"+fileSeparator);
		
		//Remove flow.xml and node.ndf from Service Path
		
		splitPath[1]=splitPath[1].replaceAll("flow.xml",""); 
		splitPath[1]=splitPath[1].replaceAll("node.ndf","");
		
		//Split at \ and format Service Name as per required format.
		
		String splitSlash[] =splitPath[1].split(fileSeparator);
		String serviceName =splitSlash[0];
		
		for (int i =1; i<splitSlash.length;i++){	
			if(i!= splitSlash.length-1)
				serviceName = serviceName +"."+splitSlash[i];
			else
				serviceName = serviceName +":"+splitSlash[i];
		}
		
		pipelineCursor.destroy();
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1,  "serviceName",serviceName );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceSignature (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceSignature)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required ServiceName
		// [o] field:0:required strInputSigStatus
		// [o] field:0:required strOutputSigStatus
		// [o] field:1:required InputsList
		// [o] field:1:required OutputsList
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	ServiceName = IDataUtil.getString( pipelineCursor, "ServiceName" );	
		NSName objNsName = NSName.create(ServiceName);
		NSService objServiceName = com.wm.app.b2b.server.ns.Namespace.getService(objNsName);
		NSSignature objSignature  = objServiceName.getSignature();
		NSRecord  objRecordInput =null;
		NSRecord  objRecordOutput =null;
		NSField[] objFieldOutput =null;
		NSField[] objFieldInput =null;
		String strInputFieldName="";
		
		if(objSignature!=null)
		{
		objRecordInput = objSignature.getInput();
		objRecordOutput = objSignature.getOutput();
		}
		String strInputSignature = "true";
		String strOutputSignature = "true";
		
		if(objRecordInput!=null)
		{
		 objFieldInput = objRecordInput.getFields();
		}
		if(objRecordOutput!=null)
			objFieldOutput = objRecordOutput.getFields();
		if(objFieldInput==null || objFieldInput.length==0)
			strInputSignature = "false";
		if(objFieldOutput==null ||objFieldOutput.length==0)
			strOutputSignature = "false";
		List<String> inputss = new ArrayList<String>();
		List<String> outputss = new ArrayList<String>();
		
		
		
		if(strInputSignature.equals("true"))
		  {
			strInputFieldName= String.valueOf(objFieldInput.length);
			for(int i=0;i<objFieldInput.length;i++)
				inputss.add( objFieldInput[i].getName());
			  
		  }
		int size1=inputss.size();
		String[] inputssArray= new String[size1];
		for(int i=0;i<size1;i++)
			inputssArray[i]= inputss.get(i);
		
		
		
		
		if(strOutputSignature.equals("true"))
		  {
			
			for(int i=0;i<objFieldOutput.length;i++)
				outputss.add(objFieldOutput[i].getName());
			  
				  
		  }
		int size2=outputss.size();
		String[] outputssArray= new String[size2];
		for(int i=0;i<size2;i++)
			outputssArray[i]= outputss.get(i);
		
		
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "strInputSigStatus", strInputSignature);
		IDataUtil.put( pipelineCursor_1, "strOutputSigStatus", strOutputSignature );
		//IDataUtil.put( pipelineCursor, "sServiceInputName", strInputFieldName );
		IDataUtil.put( pipelineCursor, "InputsList", inputssArray);
		IDataUtil.put( pipelineCursor, "OutputsList", outputssArray);
		pipelineCursor_1.destroy();
		
		
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getStringBwTwoDelimiters (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getStringBwTwoDelimiters)>> ---
		// @sigtype java 3.5
		// [i] field:0:required inputString
		// [i] field:0:required delim1
		// [i] field:0:required delim2
		// [o] field:0:required output
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inputString = IDataUtil.getString( pipelineCursor, "inputString" );
			String	delim1 = IDataUtil.getString( pipelineCursor, "delim1" );
			String	delim2 = IDataUtil.getString( pipelineCursor, "delim2" );
			
			String output = inputString.substring(inputString.indexOf(delim1)+1, inputString.indexOf(delim2));
		
		// pipeline
		IDataCursor pipelineCursor1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "output", output );
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void hasSpecialCharacter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(hasSpecialCharacter)>> ---
		// @sigtype java 3.5
		// [i] field:0:required specialCharacters
		// [i] field:0:required name
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	specialCharacters = IDataUtil.getString( pipelineCursor, "specialCharacters" );
		String	name = IDataUtil.getString( pipelineCursor, "name" );
		if(specialCharacters!=null&&specialCharacters.trim().length()!=0){
			String regex="[a-zA-Z0-9"+specialCharacters+"]+";
			if(Pattern.matches(regex, name)){
				IDataUtil.put( pipelineCursor, "flag", "true" );
			}else{
				IDataUtil.put( pipelineCursor, "flag", "false" );
			}
		}else{
			if(Pattern.matches("[0-9a-zA-Z]+", name)){
				IDataUtil.put( pipelineCursor, "flag", "false" );
			}else{
				IDataUtil.put( pipelineCursor, "flag", "true" );
			}
		}
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void isAllInLowerCase (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isAllInLowerCase)>> ---
		// @sigtype java 3.5
		// [i] field:0:required name
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	name = IDataUtil.getString( pipelineCursor, "name" );
		String regex="[a-z]+";
		if(Pattern.matches(regex,name)){
			IDataUtil.put( pipelineCursor, "flag", "true" );
		}else{
			IDataUtil.put( pipelineCursor, "flag", "false" );
		}
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isAllInUpperCase (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isAllInUpperCase)>> ---
		// @sigtype java 3.5
		// [i] field:0:required name
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	name = IDataUtil.getString( pipelineCursor, "name" );
		String regex="[A-Z]+";
		if(Pattern.matches(regex,name)){
			IDataUtil.put( pipelineCursor, "flag", "true" );
		}else{
			IDataUtil.put( pipelineCursor, "flag", "false" );
		}
		pipelineCursor.destroy();		
		// --- <<IS-END>> ---

                
	}



	public static final void isBooleanExpression (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isBooleanExpression)>> ---
		// @sigtype java 3.5
		// [i] field:0:required expression
		// [o] field:0:required isBoolean
			
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	expression = IDataUtil.getString( pipelineCursor, "expression" );
		pipelineCursor.destroy();
		String isBoolean = null; 
		if(expression.contains("==")){
			isBoolean = "true";
		}else if(expression.contains(">=")){
			isBoolean = "true";
		}else if(expression.contains("<=")){
			isBoolean = "true";
		}else if(expression.contains("!=")){
			isBoolean = "true";
		}else if(expression.contains("&&")){
			isBoolean = "true";
		}else if(expression.contains("||")){
			isBoolean = "true";
		}else if(expression.contains(">")){
			isBoolean = "true";
		}else if(expression.contains("<")){
			isBoolean = "true";
		}else{
			isBoolean = "false";
		}
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isBoolean", isBoolean );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void isRootFolderSameAsPackage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isRootFolderSameAsPackage)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:required rootFolder
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	rootFolder = IDataUtil.getString( pipelineCursor, "rootFolder" );
		String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
		if(rootFolder.equals(packageName))
			IDataUtil.put( pipelineCursor, "flag", "true" );
		else
			IDataUtil.put( pipelineCursor, "flag", "false" );
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isStartWithCompanyName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isStartWithCompanyName)>> ---
		// @sigtype java 3.5
		// [i] field:0:required companyName
		// [i] field:0:required name
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	companyName = IDataUtil.getString( pipelineCursor, "companyName" );
		String	name = IDataUtil.getString( pipelineCursor, "name" );
		String regex=".*"+companyName+".*";
		if(Pattern.matches(regex,name)){
			IDataUtil.put( pipelineCursor, "flag", "true" );
		}else{
			IDataUtil.put( pipelineCursor, "flag", "false" );
		}
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void isStartWithLowerCase (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isStartWithLowerCase)>> ---
		// @sigtype java 3.5
		// [i] field:0:required name
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	name = IDataUtil.getString( pipelineCursor, "name" );
		String regex="^[a-z].*";
		if(Pattern.matches(regex,name)){
			IDataUtil.put( pipelineCursor, "flag", "true" );
		}else{
			IDataUtil.put( pipelineCursor, "flag", "false" );
		}
		pipelineCursor.destroy();		
		// --- <<IS-END>> ---

                
	}



	public static final void isStartWithUpperCase (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isStartWithUpperCase)>> ---
		// @sigtype java 3.5
		// [i] field:0:required name
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	name = IDataUtil.getString( pipelineCursor, "name" );
		String regex="^[A-Z].*";
		if(Pattern.matches(regex,name)){
			IDataUtil.put( pipelineCursor, "flag", "true" );
		}else{
			IDataUtil.put( pipelineCursor, "flag", "false" );
		}
		pipelineCursor.destroy();	
		// --- <<IS-END>> ---

                
	}



	public static final void listToArray (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listToArray)>> ---
		// @sigtype java 3.5
		// [i] object:0:required list
		// [o] record:1:required DocumentList
		com.wm.util.List l = (com.wm.util.List) ValuesEmulator.get(pipeline, "list");
		int size = l.size();
		IData[] output = new IData[size];
		for (int i = 0; i < size; i++)
		{
		  output[i] = (IData) l.elementAt(i);
		}
		ValuesEmulator.put(pipeline, "DocumentList", output);
		// --- <<IS-END>> ---

                
	}



	public static final void mapCopyMatch (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(mapCopyMatch)>> ---
		// @sigtype java 3.5
		// [i] field:0:required IN-ARRAY
		// [i] field:0:required FROM
		// [o] field:0:required mapCopyFlag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	IN_ARRAY = IDataUtil.getString( pipelineCursor, "IN-ARRAY" );
			String	FROM = IDataUtil.getString( pipelineCursor, "FROM" );
		pipelineCursor.destroy();
		String mapCopyFlag="false";
		if(FROM.contains(IN_ARRAY+"(")){
			mapCopyFlag="true";
		}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "mapCopyFlag", mapCopyFlag );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void mapToErrorInfoWarning (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(mapToErrorInfoWarning)>> ---
		// @sigtype java 3.5
		// [i] field:0:required resultChoice
		// [i] record:0:required Result
		// [i] - field:0:required ruleId
		// [i] - field:0:required status
		// [i] - field:1:required errorList
		// [i] - field:0:required totalCount
		// [i] - field:0:required errorCount
		// [o] record:0:required Result
		// [o] - field:0:required ruleId
		// [o] - field:0:required status {"Sucess","Failure","Exception"}
		// [o] - field:0:required totalCount
		// [o] - field:0:required errorCount
		// [o] - field:1:optional errorList
		// [o] - field:0:required warnCount
		// [o] - field:1:optional warnList
		// [o] - field:0:required infoCount
		// [o] - field:1:optional infoList
			
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// Result
			IData	Result = IDataUtil.getIData( pipelineCursor, "Result" );
			String[] errorList=null;
			String errorCount=null;
			String[] infoList = null;
			String infoCount = null;
			String[] warnList = null;
			String warnCount = null;
			String totalCount = null;
			String ruleId = null;
			String status = null;
			
			if ( Result != null)
			{
				IDataCursor ResultCursor = Result.getCursor();
				errorList = IDataUtil.getStringArray( ResultCursor, "errorList" );
				errorCount = IDataUtil.getString( ResultCursor, "errorCount" );
				totalCount = IDataUtil.getString( ResultCursor, "totalCount" );
				ruleId = IDataUtil.getString( ResultCursor, "ruleId" );
				status = IDataUtil.getString( ResultCursor, "status" );
				ResultCursor.destroy();
			}
			String	resultChoice = IDataUtil.getString( pipelineCursor, "resultChoice" );
		
			if(resultChoice.equalsIgnoreCase("info")){
				infoList = errorList;
				infoCount = errorCount;
				errorList= null;
				errorCount = null;
			}
			if(resultChoice.equalsIgnoreCase("warning")){
				warnList = errorList;
				warnCount = errorCount;
				errorList = null;
				errorCount = null;
			}
		// pipeline
		
		
		// Result
		IData	Result_1 = IDataFactory.create();
		IDataCursor Result_1Cursor = Result_1.getCursor();
		IDataUtil.put( Result_1Cursor, "errorCount", errorCount);
		IDataUtil.put( Result_1Cursor, "totalCount", totalCount);
		IDataUtil.put( Result_1Cursor, "ruleId", ruleId);
		IDataUtil.put( Result_1Cursor, "status", status);
		IDataUtil.put( Result_1Cursor, "errorList", errorList);
		IDataUtil.put( Result_1Cursor, "warnCount", warnCount);
		IDataUtil.put( Result_1Cursor, "warnList", warnList );
		IDataUtil.put( Result_1Cursor, "infoCount", infoCount);
		IDataUtil.put( Result_1Cursor, "infoList", infoList );
		Result_1Cursor.destroy();
		IDataUtil.put( pipelineCursor, "Result", Result_1 );
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void removeDuplicateItemsFromList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeDuplicateItemsFromList)>> ---
		// @sigtype java 3.5
		// [i] field:1:required inStringList
		// [o] field:1:required outStringList
			
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	inStringList = IDataUtil.getStringArray( pipelineCursor, "inStringList" );
			String[] outStringList = null;
			List<String> inList = new ArrayList<String>();
			HashSet<String> hs = new HashSet<String>();
			if(inStringList != null){
				
				for(String in : inStringList){
					hs.add(in);
				}
				inList.addAll(hs);
			
			
				outStringList = new String[inList.size()];
				for(int i=0;i<inList.size();i++){
				
					outStringList[i] = inList.get(i);
				}
			}
			
		pipelineCursor.destroy();
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "outStringList", outStringList );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void stringCompare (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringCompare)>> ---
		// @sigtype java 3.5
		// [i] field:0:required string1
		// [i] field:0:required string2
		// [o] field:0:required flag
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	string1 = IDataUtil.getString( pipelineCursor, "string1" );
			String	string2 = IDataUtil.getString( pipelineCursor, "string2" );
		pipelineCursor.destroy();
		String flag="false";
		if(null!=string1){
		if(string1.equals(string2)){
			flag="true"; 
			}
		}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "flag", flag );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void stringListToString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringListToString)>> ---
		// @sigtype java 3.5
		// [i] field:0:required index
		// [i] field:1:required stringList
		// [o] field:0:required string
			
		
		// pipeline
		String string = null;
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	index = IDataUtil.getString( pipelineCursor, "index" );
		String[] stringList = IDataUtil.getStringArray( pipelineCursor, "stringList" );
		if(Integer.parseInt(index) > -1)
			string = stringList[Integer.parseInt(index)];
		
		// pipeline
		//IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "string", string );
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void trimFields (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(trimFields)>> ---
		// @sigtype java 3.5
		// [i] record:0:required inputDocument
		// [i] field:0:required removeEmptyFields
		// [o] record:0:required outputDocument
		// pipeline
		IDataCursor cursor = pipeline.getCursor();
		boolean removeEmptyFields = false;
		
		IData inputDocument = IDataUtil.getIData(cursor, "inputDocument");
		
		if (inputDocument == null)
		{
		  throw new ServiceException("Missing input 'inputDocument'");
		}
		
		if (cursor.first("removeEmptyFields"))
		{
		  removeEmptyFields = Boolean.valueOf((String) cursor.getValue()).booleanValue();
		}
		
		IData outIData = trimValues(inputDocument, removeEmptyFields);
		IDataUtil.put(cursor, "outputDocument", outIData);
		cursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static List<String> RootFolders=new ArrayList<String>();
	private static List<String> SubFolders = new ArrayList<String>();
	private static List<String> Services = new ArrayList<String>();
	private static List<String> NodePathList = new ArrayList<String>();
	private static List<String> FlowNodePathList = new ArrayList<String>();
	private static List<String> FlowPathList = new ArrayList<String>();
	private static List<String> JavaPathList = new ArrayList<String>();
	private static List<String> FlowJavaNodePathList = new ArrayList<String>();
	private static List<String> ServiceDirPathList = new ArrayList<String>();
	private static int count=0;
	private static int depth=0;
	
	private static void recurseThroughDoc(Element node,int NoOfLevel) {
	    Iterator it = node.getChildren().iterator();
	    if(depth <= NoOfLevel){ 
	    	
	      while(it.hasNext()){
	              depth++;
	              count++;
	          //System.out.println("depth++"+depth);
	            Element child=(Element)it.next();
	              child.removeChild("COMMENT");
	          if(depth <= NoOfLevel){
	              recurseThroughDoc( child, NoOfLevel);
	          }   
	      }
	    }
	}
		
	static private void getFileListing(File DirPath) throws FileNotFoundException {
		String[] sFilesAndDirs = DirPath.list();
		File[] fFilesAndDirs= DirPath.listFiles();
		List<String> contents = Arrays.asList(sFilesAndDirs);
	
		
		if (contents.contains("node.ndf")) {
			Services.add(DirPath.getName());
			NodePathList.add(DirPath.getAbsolutePath()+File.separator+"node.ndf");
			if(contents.contains("flow.xml")){
				FlowPathList.add(DirPath.getAbsolutePath()+File.separator+"flow.xml");
				FlowJavaNodePathList.add(DirPath.getAbsolutePath()+File.separator+"node.ndf");
				FlowNodePathList.add(DirPath.getAbsolutePath()+File.separator+"node.ndf");
				ServiceDirPathList.add(DirPath.getAbsolutePath()+File.separator);
				
			}
			if(contents.contains("java.frag")){
				JavaPathList.add(DirPath.getAbsolutePath()+File.separator+"java.frag");
	            FlowJavaNodePathList.add(DirPath.getAbsolutePath()+File.separator+"node.ndf");
			}
		} else if (contents.contains("node.idf")) {
			SubFolders.add(DirPath.getName());
		for (File file : fFilesAndDirs) {
			if (!file.toString().endsWith("node.idf")) {
				getFileListing(file);
			}
		}
	} else {
		for (File file : fFilesAndDirs) {
				RootFolders.add(file.getName());
				getFileListing(file);
		}
	}
	}
	
	private static IData removeNullFields(IData inIData, boolean removeEmpty, boolean trimFields)
	{
	  IData outIData = IDataFactory.create();
	  IDataCursor outCursor = outIData.getCursor();
	  IDataCursor inCursor = inIData.getCursor();
	
	  while (inCursor.next())
	  {
	    Object obj = inCursor.getValue();
	    if (obj == null)
	    {
	      continue;
	    }
	
	    if (obj instanceof String)
	    {
	      String temp = (String) obj;
	      if (trimFields)
	      {
	        temp = temp.trim();
	      }
	
	      if (temp.length() > 0 || !removeEmpty)
	      {
	        IDataUtil.put(outCursor, inCursor.getKey(), temp);
	      }
	    }
	    else if (obj instanceof IData)
	    {
	      IData out = removeNullFields((IData) obj, removeEmpty, trimFields);
	      if (out != null && out.getCursor().hasMoreData())
	      {
	        IDataUtil.put(outCursor, inCursor.getKey(), out);
	      }
	    }
	    else if (obj instanceof IData[])
	    {
	      IData[] objArray = (IData[]) obj;
	      ArrayList outArrayList = new ArrayList();
	
	      for (int i = 0; i < objArray.length; i++)
	      {
	        IData out = removeNullFields(objArray[i], removeEmpty, trimFields);
	        if (out != null && out.getCursor().hasMoreData())
	        {
	          outArrayList.add(out);
	        }
	      }
	
	      IData[] outArray = null;
	      if (outArrayList.size() > 0)
	      {
	        outArray = new IData[outArrayList.size()];
	        outArrayList.toArray(outArray);
	        IDataUtil.put(outCursor, inCursor.getKey(), outArray);
	      }
	    }
	    else
	    {
	      IDataUtil.put(outCursor, inCursor.getKey(), obj);
	    }
	  }
	  outCursor.destroy();
	  inCursor.destroy();
	  return outIData;
	}
	
	private static IData trimValues(IData inIData, boolean removeEmptyFields)
	{
	  IData outIData = IDataFactory.create();
	  IDataCursor outCursor = outIData.getCursor();
	  IDataCursor inCursor = inIData.getCursor();
	
	  while (inCursor.next())
	  {
	    Object obj = inCursor.getValue();
	    if (obj instanceof String)
	    {
	      if (obj != null)
	      {
	        String temp = ((String) obj).trim();
	        if (temp.length() > 0 || removeEmptyFields == false)
	        {
	          IDataUtil.put(outCursor, inCursor.getKey(), temp);
	        }
	        else
	        {
	          IDataUtil.put(outCursor, inCursor.getKey(), null);
	        }
	      }
	    }
	    else if (obj instanceof IData)
	    {
	      IDataUtil.put(outCursor, inCursor.getKey(), trimValues((IData) obj, removeEmptyFields));
	    }
	    else if (obj instanceof IData[])
	    {
	      IData[] objArray = (IData[]) obj;
	      IData[] outArray = new IData[objArray.length];
	      for (int i = 0; i < objArray.length; i++)
	      {
	        outArray[i] = trimValues(objArray[i], removeEmptyFields);
	      }
	      IDataUtil.put(outCursor, inCursor.getKey(), outArray);
	    }
	    else
	    {
	      IDataUtil.put(outCursor, inCursor.getKey(), obj);
	    }
	  }
	  outCursor.destroy();
	  inCursor.destroy();
	  return outIData;
	}
	// --- <<IS-END-SHARED>> ---
}

