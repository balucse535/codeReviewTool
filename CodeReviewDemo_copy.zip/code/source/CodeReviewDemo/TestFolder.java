package CodeReviewDemo;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2017-04-11 11:44:37 IST
// -----( ON-HOST: HSCSRV164.allegisgroup.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
// --- <<IS-END-IMPORTS>> ---

public final class TestFolder

{
	// ---( internal utility methods )---

	final static TestFolder _instance = new TestFolder();

	static TestFolder _newInstance() { return new TestFolder(); }

	static TestFolder _cast(Object o) { return (TestFolder)o; }

	// ---( server methods )---




	public static final void dateTimeConversion (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(dateTimeConversion)>> ---
		// @sigtype java 3.5
		// [i] field:0:required date
		// [o] field:0:required convertDate
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	date = IDataUtil.getString( pipelineCursor, "date" );
		pipelineCursor.destroy();
		
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		 String newDateString = df.format(date);
		
		DateFormat gmtFormat = new SimpleDateFormat();
		TimeZone gmtTime = TimeZone.getTimeZone("GMT");
		gmtFormat.setTimeZone(gmtTime);
		
		 newDateString=gmtFormat.format(newDateString);
		// pipeline
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				IDataUtil.put( pipelineCursor_1, "convertDate", newDateString );
				pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

