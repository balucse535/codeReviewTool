package CodeReviewTool;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-02-18 15:48:56 IST
// -----( ON-HOST: HSC-C32Z6BS.allegisgroup.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
// --- <<IS-END-IMPORTS>> ---

public final class favourite

{
	// ---( internal utility methods )---

	final static favourite _instance = new favourite();

	static favourite _newInstance() { return new favourite(); }

	static favourite _cast(Object o) { return (favourite)o; }

	// ---( server methods )---




	public static final void createFavouriteFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createFavouriteFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required xmlData
		// [i] field:0:required fileName
		// [i] field:0:required fileDir
		// [o] field:0:required status
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	xmlData = IDataUtil.getString( pipelineCursor, "xmlData" );
			String	fileName = IDataUtil.getString( pipelineCursor, "fileName" );
			String	fileDir = IDataUtil.getString( pipelineCursor, "fileDir" );
			String stat = "FAILED";
			
			try {
		        //Whatever the file path is.
		        File statText = new File(fileDir+fileName);
		        FileOutputStream is = new FileOutputStream(statText);
		        OutputStreamWriter osw = new OutputStreamWriter(is);    
		        Writer w = new BufferedWriter(osw);
		        w.write(xmlData);
		        w.close();
		        stat = "SUCCESS";
		    } catch (IOException e) {
		        stat = e.getMessage();
		    }
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "status", stat );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}
}

